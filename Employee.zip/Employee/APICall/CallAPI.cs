﻿using APICall.Model;
using APICall.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace APICall
{
    public partial class CallAPI : Form
    {
        UserApiRepository _repository = new UserApiRepository();
        string Gender = string.Empty, Status = string.Empty;
        int pagecount = 0, currentpage = 0;
        public CallAPI()
        {
            InitializeComponent();
            
            LoadPageData();
        }
        
       
        public async void LoadPageData(int pagenumber = 1)
        {
            var listw = await _repository.GetUsersPage(pagenumber);
            UserListView.DataSource = listw.data;
            lblPageNumber.Text = string.Format("Page {0}/{1}", listw.meta.pagination.page, listw.meta.pagination.limit);
            pagecount = listw.meta.pagination.limit;
            currentpage = listw.meta.pagination.page;
          
        }       

        private async void UserListView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
            if (UserListView.Columns[e.ColumnIndex].HeaderText == "Remove")
            {
                int id;
                id = Convert.ToInt32(UserListView.Rows[e.RowIndex].Cells["id"].Value);
                string res =await _repository.Delete(id);
                if (res == "OK")
                {
                    MessageBox.Show("Employee " + Convert.ToString(UserListView.Rows[e.RowIndex].Cells["name"].Value) + " Deleted successfully");
                    LoadPageData();
                }
                else
                {
                    MessageBox.Show("Employee " + Convert.ToString(UserListView.Rows[e.RowIndex].Cells["name"].Value) + "not Deleted");
                }
            }
            if (UserListView.Columns[e.ColumnIndex].HeaderText == "Update")
            {
                Datum data = new Datum();
                data.id = Convert.ToInt32(UserListView.Rows[e.RowIndex].Cells["id"].Value);
                data.name = Convert.ToString(UserListView.Rows[e.RowIndex].Cells["name"].Value);
                data.email = Convert.ToString(UserListView.Rows[e.RowIndex].Cells["email"].Value);
                data.gender = Convert.ToString(UserListView.Rows[e.RowIndex].Cells["gender"].Value);
                data.status = Convert.ToString(UserListView.Rows[e.RowIndex].Cells["status"].Value);
                Form frmBackground = new Form();

                try
                {
                    using (Update U = new Update(data))
                    {
                        
                        frmBackground.StartPosition = FormStartPosition.Manual;
                        frmBackground.FormBorderStyle = FormBorderStyle.None;
                        frmBackground.Opacity = .70d;
                        frmBackground.BackColor = Color.Black;
                        frmBackground.WindowState = FormWindowState.Normal;
                        frmBackground.TopMost = false;
                        frmBackground.Location = this.Location; ;
                        frmBackground.ShowInTaskbar = false;
                        frmBackground.Show();
                        U.Owner = frmBackground;
                        U.ShowDialog();
                        frmBackground.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    frmBackground.Dispose();
                }


                }
            }
                  
       
        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (Validate() == 1)
            {
                Datum data = new Datum();

                data.name = txtName.Text;
                data.email = txtEmail.Text;
                if (rdbMale.Checked == true)
                {
                    data.gender = rdbMale.Text.ToString();
                }
                else
                {
                    data.gender = rdbFemale.Text.ToString();
                }
                if (rdbActive.Checked == true)
                {
                    data.status = rdbActive.Text.ToString();
                }
                else
                {
                    data.status = rdbInactive.Text.ToString();
                }
                var response = await _repository.Post(data);

                LoadPageData();
                Clear();

            }
        }

        private async void btnPrevious_Click(object sender, EventArgs e)
        {
            
            if (currentpage!=1)
            {
                var listw = await _repository.GetUsersPage(--currentpage);
                UserListView.DataSource = listw.data;
                lblPageNumber.Text = string.Format("Page {0}/{1}", listw.meta.pagination.page, listw.meta.pagination.limit);
                pagecount = listw.meta.pagination.limit;
                currentpage = listw.meta.pagination.page;
            }
        }

        private async void btnNext_Click(object sender, EventArgs e)
        {
           
                if (currentpage != pagecount)
                {
                    var listw = await _repository.GetUsersPage(++currentpage);
                    UserListView.DataSource = listw.data;
                    lblPageNumber.Text = string.Format("Page {0}/{1}", listw.meta.pagination.page, listw.meta.pagination.limit);
                    pagecount = listw.meta.pagination.limit;
                    currentpage = listw.meta.pagination.page;
                }
            
        }

        private void CallAPI_Activated(object sender, EventArgs e)
        {
            LoadPageData();
        }

        
        private int Validate()
        {
            int validate = 1;
            if (string.IsNullOrEmpty(txtName.Text))
            {
                MessageBox.Show("Name cannot be empty");
                validate = 0;
            }
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                MessageBox.Show("Email cannot be empty");
                validate = 0;
            }
            if (rdbActive.Checked!=true&&rdbInactive.Checked!=true)
            {
                MessageBox.Show("Please select Status");
                validate = 0;
            }
            if (rdbMale.Checked != true && rdbFemale.Checked != true)
            {
                MessageBox.Show("Please select Gender");
                validate = 0;
            }
            return validate;
        }
        private void Clear()
        {
            txtEmail.Text = string.Empty;
            txtName.Text = string.Empty;
            rdbActive.Checked = false;
            rdbInactive.Checked = false;
            rdbMale.Checked = false;
            rdbFemale.Checked = false;
        }
    }
}
