﻿using APICall.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace APICall.Repository
{
    public class UserApiRepository
    {
        
        public UserApiRepository()
        {
            
        }
        public async Task<User> GetUsers()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://gorest.co.in/public-api/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
                using (HttpResponseMessage res = await client.GetAsync($"users"))
                {
                    var json = await res.Content.ReadAsStringAsync();
                    var listw = JsonConvert.DeserializeObject<User>(json);
                    return listw;
                }
            }
        }

        public async Task<User> GetUsersPage(int page)
        {
            using (HttpClient client = new HttpClient())
            {
                //client.BaseAddress = new Uri("https://gorest.co.in/public-api/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
                using (HttpResponseMessage res = await client.GetAsync("https://gorest.co.in/public-api/users?page"+page))
                {
                    var json = await res.Content.ReadAsStringAsync();
                    var listw = JsonConvert.DeserializeObject<User>(json);
                    return listw;
                }
            }
        }


        public  async Task<string> Post(Datum data)
        {
            var inputData = new Dictionary<string, string>
            {
                {
                    "name",data.name
                },
                {"email",data.email },
                {"gender",data.gender },
                {"status",data.status }
            };
            var input = new FormUrlEncodedContent(inputData);
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://gorest.co.in/public-api/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
                using (HttpResponseMessage res = await client.PostAsync($"users",input))
                {
                    using (HttpContent content = res.Content)
                    {
                        string data1 = await content.ReadAsStringAsync();
                        if (data1 != null)
                        {
                            return data1;

                        }
                        else
                        {
                            return string.Empty;
                        }
                    }
                }
            }

        }
        public async Task<string> Put(Datum data)
        {
            var inputData = new Dictionary<string, string>
            {
                {"name",data.name},
                {"email",data.email },
                {"gender",data.gender },
                {"status",data.status }
            };
            var input = new FormUrlEncodedContent(inputData);
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://gorest.co.in/public-api/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
                using (HttpResponseMessage res = await client.PutAsync($"users/"+data.id, input))
                {
                    using (HttpContent content = res.Content)
                    {
                        string data1 = await content.ReadAsStringAsync();
                        if (data1 != null)
                        {
                            return res.StatusCode.ToString();

                        }
                        else
                        {
                            return string.Empty;
                        }
                    }
                }
            }
        }
        public async Task<Datum> Get(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://gorest.co.in/public-api/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
                using (HttpResponseMessage res = await client.GetAsync($"users/" + id))
                {
                    var json = await res.Content.ReadAsStringAsync();
                    var listw = JsonConvert.DeserializeObject<Datum>(json);
                    return listw;
                }
            }

        }

        public async Task<string> Delete(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://gorest.co.in/public-api/");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
                using (HttpResponseMessage res = await client.DeleteAsync($"users/"+id))
                {
                    using (HttpContent content = res.Content)
                    {
                        string data1 = await content.ReadAsStringAsync();
                        if (data1 != null)
                        {
                            return res.StatusCode.ToString();

                        }
                        else
                        {
                            return string.Empty;
                        }
                    }
                }
            }
           
        }





    }
}