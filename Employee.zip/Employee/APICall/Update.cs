﻿using APICall.Model;
using APICall.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APICall
{
    public partial class Update : Form
    {
        Datum _data = new Datum();
        
        UserApiRepository _repository = new UserApiRepository();
        public Update(Datum data)
        {
            InitializeComponent();
            _data.id = data.id;
            _data.name = data.name;
            _data.email = data.email;
            _data.gender = data.gender;
            _data.status = data.status;
        }

        private void Update_Load(object sender, EventArgs e)
        {
            txtID.Text = _data.id.ToString();
            txtName.Text = _data.name;
            txtEmail.Text = _data.email;
            txtGender.Text = _data.gender;
            txtStatus.Text = _data.status;


        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            Datum data = new Datum();
            data.id = Convert.ToInt32(txtID.Text);
            data.name = txtName.Text;
            data.email = txtEmail.Text;
            data.gender = txtGender.Text;
            data.status = txtStatus.Text;
            var response = await _repository.Put(data);         
            this.Close();
        }
                
    }
}
